import { ChangeDetectorRef, Component, inject, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Api, Auth, Jogador, mensagemErro } from '../../services/api';
@Component({
  selector: 'app-perfil',
  imports: [RouterLink, ReactiveFormsModule],
  templateUrl: './perfil.html',
  styleUrl: './perfil.css',
})


export class Perfil implements OnInit {
  private cdr = inject(ChangeDetectorRef);
  private api = inject(Api);
  private auth = inject(Auth);
  jogador: Jogador | null = null;
  loading = false;
  busy = false;
  erro = '';
  sucesso = '';
  form = new FormGroup({
    cpf: new FormControl('', {
      nonNullable: true,
      validators: [
        Validators.pattern(/^(\d{11}|\d{3}\.\d{3}\.\d{3}-\d{2})$/)
      ],
    }),
    cep: new FormControl('', {
      nonNullable: true,
      validators: [Validators.pattern(/^\d{5}-?\d{3}$/)],
    }),
    descricao: new FormControl('', { nonNullable: true, validators: [Validators.maxLength(500)] }),
    altura: new FormControl<number | null>(null, [Validators.min(0.01), Validators.max(3)]),
  });
  ngOnInit() {
    this.carregar();
  }
  carregar() {
    this.loading = true;
    this.erro = '';
    this.api.perfil(this.auth.sessao()!.jogadorId).subscribe({
      next: (j) => {
        this.cdr.markForCheck();
        this.jogador = j;
        this.form.patchValue({ cep: j.cep || '', descricao: j.descricao || '', altura: j.altura });
        this.loading = false;
      },
      error: (e) => {
        this.cdr.markForCheck();
        this.loading = false;
        this.erro = mensagemErro(e);
      },
    });
  }
  salvar() {
    if (this.busy) return;
    this.form.markAllAsTouched();
    if (this.form.invalid) return;
    const v = this.form.getRawValue();
    this.busy = true;
    this.erro = '';
    this.sucesso = '';
    this.api
      .salvarPerfil(this.auth.sessao()!.jogadorId, {
        descricao: v.descricao,
        ...(v.cpf ? { cpf: v.cpf.replace(/\D/g, '') } : {}),
        ...(v.cep ? { cep: v.cep.replace(/\D/g, '') } : {}),
        ...(v.altura !== null ? { altura: v.altura } : {}),
      })
      .subscribe({
        next: (j) => {
          this.cdr.markForCheck();
          this.jogador = j;
          this.busy = false;
          this.form.controls.cpf.reset();
          this.sucesso = 'Perfil atualizado!';
        },
        error: (e) => {
          this.cdr.markForCheck();
          this.busy = false;
          this.erro = mensagemErro(e);
        },
      });
  }
}
